/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package application;

import javafx.scene.paint.Color;

/**
 *
 * @author mtg
 */
public class GlobalsAxesColors {

	// COLORS OF THE AXES

	// Axes for centered (ox, oy) given

	static Color colorAxesCentered = Color.RED;

	// Axes for moved (ox=0, oy=0) given

	static Color colorAxesMoved = Color.FUCHSIA;

}
