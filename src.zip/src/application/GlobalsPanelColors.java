package application;

import javafx.scene.paint.Color;

public class GlobalsPanelColors {
    
    
    
    
    
    
    

    // COLORS OF PANEL CENTER GRAPHICS
    static Color colorPanelCGraphicsBackground = Color.WHITE;

    static Color colorPanelCGraphicsBorder = Color.BLACK;

    // COLORS OF MAIN PANEL
    // MAIN PANEL BACKGROUND
    static Color colorPanelMainBackground = Color.BLUE;

    // MAIN PANEL BORDER
    static Color colorPanelMainBorder = Color.BLACK;

    // -------------------------------------------------------------------
    // COLORS OF TOP PANEL LINE 1
    // TOP PANEL LINE 1 COLOR BACKGROUND
    static Color colorPanelTopLine1Background = Color.FLORALWHITE;

    // TOP PANEL LINE 1 COLOR BORDER
    static Color colorPanelTopLine1Border = Color.BLACK;

    // COLORS OF TOP PANEL LINE 2
    // TOP PANEL LINE 2 COLOR BACKGROUND
    static Color colorPanelTopLine2Background = Color.ANTIQUEWHITE;

    // TOP PANEL LINE 2 COLOR BORDER
    static Color colorPanelTopLine2Border = Color.BLACK;

    // COLORS OF TOP PANEL LINE 3
    // TOP PANEL LINE 3 COLOR BACKGROUND
    static Color colorPanelTopLine3Background = Color.FLORALWHITE;

    // TOP PANEL LINE 2 COLOR BORDER
    static Color colorPanelTopLine3Border = Color.BLACK;

    // COLORS OF C-TOP PANEL LINE 1
    // C-TOP PANEL LINE 1 COLOR BACKGROUND
    static Color colorPanelCTopLine1Background = Color.ANTIQUEWHITE;

    // C-TOP PANEL LINE 1 COLOR BORDER
    static Color colorPanelCTopLine1Border = Color.BLACK;

    // COLORS OF C-TOP PANEL LINE 2
    // C-TOP PANEL LINE 2 COLOR BACKGROUND
    static Color colorPanelCTopLine2Background = Color.FLORALWHITE;

    // C-TOP PANEL LINE 2 COLOR BORDER
    static Color colorPanelCTopLine2Border = Color.BLACK;

    // --------------------------------------------------------
    // COLORS OF BOTTOM PANEL LINE 1
    // BOTTOM PANEL LINE 1 COLOR BACKGROUND
    static Color colorPanelBottomLine1Background = Color.FLORALWHITE;

    // BOTTOM PANEL LINE 1 COLOR BORDER
    static Color colorPanelBottomLine1Border = Color.BLACK;

    // COLORS OF BOTTOM PANEL LINE 2
    // BOTTOM PANEL LINE 2 COLOR BACKGROUND
    static Color colorPanelBottomLine2Background = Color.ANTIQUEWHITE;

    // BOTTOM PANEL LINE 2 COLOR BORDER
    static Color colorPanelBottomLine2Border = Color.BLACK;

    // COLORS OF C-BOTTOM PANEL LINE 1
    // C-BOTTOM PANEL LINE 1 COLOR BACKGROUND
    static Color colorPanelCBottomLine1Background = Color.FLORALWHITE;

    // C-BOTTOM PANEL LINE 1 COLOR BORDER
    static Color colorPanelCBottomLine1Border = Color.BLACK;

    // COLORS OF C-BOTTOM PANEL LINE 2
    // C-BOTTOM PANEL LINE 2 COLOR BACKGROUND
    static Color colorPanelCBottomLine2Background = Color.ANTIQUEWHITE;

    // C-BOTTOM PANEL LINE 2 COLOR BORDER
    static Color colorPanelCBottomLine2Border = Color.BLACK;

}
